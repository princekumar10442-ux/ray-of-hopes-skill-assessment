// ==========================================================================
// seed.js — Database Seed Script
//
// Run this file's function from the browser console to bulk insert all
// local hardcoded questions into the Supabase database.
//
// Usage in console: await seedDatabase()
// ==========================================================================

async function seedDatabase() {
  const sb = getSupabaseClient();
  if (!sb) {
    throw new Error("Supabase is not configured in js/config.js.");
  }

  const { data: { session }, error: sessionError } = await sb.auth.getSession();
  if (sessionError) throw sessionError;
  if (!session) throw new Error("Sign in to the Teacher Portal first, then run the seed command on this same site.");

  const banks = {
    primary:   window.QUESTIONS_PRIMARY,
    middle:    window.QUESTIONS_MIDDLE,
    secondary: window.QUESTIONS_SECONDARY,
    higher:    window.QUESTIONS_HIGHER,
    graduate:  window.QUESTIONS_GRADUATE,
  };

  const recordsToInsert = [];

  for (const [level, bank] of Object.entries(banks)) {
    if (!bank) continue;
    
    for (const [section, questions] of Object.entries(bank)) {
      for (const q of questions) {
        recordsToInsert.push({
          education_level: level,
          section: section,
          question: q.question,
          options: q.options,
          correct_index: q.correctIndex,
          is_active: true
        });
      }
    }
  }

  // Remove duplicate prompts in the local source, then skip rows already
  // stored so rerunning the seed command won't create duplicate question rows.
  const localSeen = new Set();
  const uniqueRecords = recordsToInsert.filter(question => {
    const key = `${question.education_level}\u0000${question.section}\u0000${question.question.trim().toLocaleLowerCase()}`;
    if (localSeen.has(key)) return false;
    localSeen.add(key);
    return true;
  });
  const existing = new Set();
  const pageSize = 1000;
  for (let offset = 0; ; offset += pageSize) {
    const { data, error } = await sb.from("questions")
      .select("education_level,section,question")
      .range(offset, offset + pageSize - 1);
    if (error) throw error;
    (data || []).forEach(question => {
      existing.add(`${question.education_level}\u0000${question.section}\u0000${question.question.trim().toLocaleLowerCase()}`);
    });
    if (!data || data.length < pageSize) break;
  }
  const missing = uniqueRecords.filter(question =>
    !existing.has(`${question.education_level}\u0000${question.section}\u0000${question.question.trim().toLocaleLowerCase()}`)
  );
  if (!missing.length) {
    console.log("All bundled questions are already in the database. Nothing to add.");
    return { inserted: 0, existing: uniqueRecords.length };
  }

  console.log(`Adding ${missing.length} new questions (${uniqueRecords.length - missing.length} already present).`);

  // Insert in batches of 50 to avoid any potential limits
  const batchSize = 50;
  for (let i = 0; i < missing.length; i += batchSize) {
    const batch = missing.slice(i, i + batchSize);
    const { data, error } = await sb.from("questions").insert(batch);
    
    if (error) {
      throw new Error(`Could not insert question batch ${i / batchSize + 1}: ${error.message}`);
    }
    console.log(`Inserted batch ${i / batchSize + 1} / ${Math.ceil(missing.length / batchSize)}`);
  }

  console.log("✅ Database seeding complete!");
  return { inserted: missing.length, existing: uniqueRecords.length - missing.length };
}

// Attach to window so it can be run from DevTools
window.seedDatabase = seedDatabase;
