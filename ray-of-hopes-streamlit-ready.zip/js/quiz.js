// ==========================================================================
// quiz.js — Question selection & quiz rendering
// ==========================================================================

function getQuestionBank(level) {
  const banks = {
    primary: window.QUESTIONS_PRIMARY,
    middle: window.QUESTIONS_MIDDLE,
    secondary: window.QUESTIONS_SECONDARY,
    higher: window.QUESTIONS_HIGHER,
    graduate: window.QUESTIONS_GRADUATE,
  };

  return banks[level] || null;
}


// --------------------------------------------------------------------------
// Fisher-Yates shuffle
// --------------------------------------------------------------------------

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }

  return arr;
}

function normalizeQuestion(question, section = "") {
  if (!question || typeof question.question !== "string" || !question.question.trim()) return null;

  let options = question.options;
  if (typeof options === "string") {
    try { options = JSON.parse(options); } catch { return null; }
  }

  const rawCorrectIndex = question.correctIndex ?? question.correct_index;
  const correctIndex = Number(rawCorrectIndex);
  if (
    !Array.isArray(options) || options.length < 2 ||
    options.some(option => !String(option).trim()) ||
    rawCorrectIndex === null || rawCorrectIndex === undefined ||
    !Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex >= options.length
  ) return null;

  return {
    ...question,
    question: question.question.trim(),
    options: options.map(option => String(option)),
    section: section || question.section || question.category || "",
    correctIndex
  };
}


// --------------------------------------------------------------------------
// Select random questions
// 5 sections × 4 questions = 20 questions
// --------------------------------------------------------------------------

async function selectRandomQuestions(level, perSection = 4) {

  const sectionOrder = [
    "Basic Computers",
    "English",
    "Aptitude",
    "Logical Reasoning",
    "General Awareness"
  ];

  let questionsPool = [];

  // ------------------------------------------------------------------------
  // 1. Load LOCAL question bank first
  // ------------------------------------------------------------------------

  const localBank = getQuestionBank(level);

  if (localBank) {

    for (const [section, questions] of Object.entries(localBank)) {

      questionsPool = questionsPool.concat(
        questions.map(q => normalizeQuestion(q, section)).filter(Boolean)
      );

    }

  } else {

    console.error(`No local question bank found for level: ${level}`);

  }


  // ------------------------------------------------------------------------
  // 2. Try Supabase
  // ------------------------------------------------------------------------

  const sb =
    typeof getSupabaseClient === "function"
      ? getSupabaseClient()
      : null;


  if (sb) {

    try {

      const { data, error } = await sb
        .from("questions")
        .select("*")
        .eq("education_level", level)
        .eq("is_active", true);

      if (error) {
        throw error;
      }


      // --------------------------------------------------------------------
      // If Supabase has questions, use them for their respective sections.
      // Missing sections will continue using the local question bank.
      // --------------------------------------------------------------------

      if (data && data.length > 0) {

        const dbQuestions = data.map(q => normalizeQuestion(q)).filter(Boolean);


        // Replace local questions with DB questions
        // section-by-section.

        const dbBySection = {};

        dbQuestions.forEach(q => {

          if (!q.section) {
            return;
          }

          if (!dbBySection[q.section]) {
            dbBySection[q.section] = [];
          }

          dbBySection[q.section].push(q);

        });


        // Prefer the database set when it can fill the section by itself.
        // If it has only a partial section, keep the local questions too so
        // a partially seeded database never prevents a learner from starting.

        questionsPool = questionsPool.filter(
          q => (dbBySection[q.section]?.length || 0) < perSection
        );


        // Add Supabase questions.

        questionsPool = questionsPool.concat(dbQuestions);

      }

    } catch (err) {

      console.warn(
        "Supabase question fetch failed. Using local question banks.",
        err
      );

    }

  }


  // ------------------------------------------------------------------------
  // 3. Group questions by section
  // ------------------------------------------------------------------------

  const poolBySection = {};

  questionsPool.forEach(q => {

    if (!q.section) {
      return;
    }

    if (!poolBySection[q.section]) {
      poolBySection[q.section] = [];
    }

    poolBySection[q.section].push(q);

  });

  // Repeated database seeds can create duplicate rows. Remove identical
  // prompts and choices so one quiz never asks the same question twice.
  for (const section of Object.keys(poolBySection)) {
    const unique = new Map();
    poolBySection[section].forEach(q => {
      const key = `${q.question.toLocaleLowerCase()}\u0000${q.options.map(option => option.toLocaleLowerCase()).join("\u0000")}`;
      if (!unique.has(key)) unique.set(key, q);
    });
    poolBySection[section] = [...unique.values()];
  }


  // ------------------------------------------------------------------------
  // 4. Select questions in REQUIRED order
  // ------------------------------------------------------------------------

  const selected = [];

  for (const section of sectionOrder) {

    const pool = poolBySection[section];

    if (!pool || pool.length < perSection) {
      const available = pool?.length || 0;
      throw new Error(`${section} has ${available} valid questions; ${perSection} are required.`);
    }


    const shuffled = shuffle([...pool]);

    const picked = shuffled.slice(0, perSection);


    selected.push(...picked);

  }


  console.log(
    `${level}: Selected ${selected.length} questions`,
    selected.map(q => q.section)
  );


  return selected;

}


// --------------------------------------------------------------------------
// Render current question
// --------------------------------------------------------------------------

function renderQuestion() {

  const q = state.activeQuestions[state.currentQuestionIndex];

  const total = state.activeQuestions.length;

  const idx = state.currentQuestionIndex;


  // Section label

  dom.sectionLabel.textContent = q.section;


  // Progress

  const progressPct =
    Math.round(((idx + 1) / total) * 100);

  dom.progressText.textContent =
    `Question ${idx + 1} of ${total}`;

  dom.progressBar.style.width =
    `${progressPct}%`;

  dom.progressBarCont.setAttribute(
    "aria-valuenow",
    progressPct
  );


  // Question

  dom.questionTitle.textContent =
    q.question;

  if (dom.quizFeedback) dom.quizFeedback.textContent = "";


  // Options

  dom.optionsContainer.innerHTML = "";

  const savedAnswer = state.answers[idx];
  const savedSelection = savedAnswer && !savedAnswer.skipped
    ? savedAnswer.selectedIndex
    : null;


  q.options.forEach((optText, optIdx) => {

    const btn = document.createElement("button");

    btn.type = "button";

    btn.className =
      "option-card w-full text-left border-2 border-gray-300 rounded-xl px-5 py-4 " +
      "text-base sm:text-lg font-medium text-gray-800 cursor-pointer";


    btn.setAttribute("role", "radio");

    btn.setAttribute("aria-checked", String(savedSelection === optIdx));
    btn.tabIndex = savedSelection === optIdx || (savedSelection === null && optIdx === 0) ? 0 : -1;
    if (savedSelection === optIdx) btn.classList.add("selected");

    btn.textContent = optText;


    btn.addEventListener(
      "click",
      () => handleOptionSelect(optIdx)
    );

    btn.addEventListener("keydown", (event) => {
      const direction = event.key === "ArrowRight" || event.key === "ArrowDown" ? 1
        : event.key === "ArrowLeft" || event.key === "ArrowUp" ? -1
        : 0;
      if (!direction) return;
      event.preventDefault();
      const nextIndex = (optIdx + direction + q.options.length) % q.options.length;
      handleOptionSelect(nextIndex);
      dom.optionsContainer.querySelectorAll(".option-card")[nextIndex].focus();
    });


    dom.optionsContainer.appendChild(btn);

  });


  // Reset selection

  state.selectedOptionIndex = savedSelection;
  dom.btnNext.disabled = savedSelection === null;
  dom.btnPrevious.disabled = idx === 0;
  renderQuestionNavigator();


  // Last question button

  dom.btnNext.textContent =
    idx === total - 1
      ? "See Results →"
      : "Next →";

}

function renderQuestionNavigator() {
  if (!dom.questionNavigator) return;
  dom.questionNavigator.replaceChildren();
  state.activeQuestions.forEach((_, index) => {
    const answer = state.answers[index];
    const status = answer?.skipped ? "skipped" : answer ? "answered" : "not answered";
    const button = document.createElement("button");
    button.type = "button";
    button.className = `question-map-button ${index === state.currentQuestionIndex ? "current" : ""} ${answer?.skipped ? "skipped" : answer ? "answered" : ""}`;
    button.textContent = String(index + 1);
    button.setAttribute("aria-label", `Question ${index + 1}, ${status}${index === state.currentQuestionIndex ? ", current question" : ""}`);
    if (index === state.currentQuestionIndex) button.setAttribute("aria-current", "step");
    button.addEventListener("click", () => goToQuestion(index));
    dom.questionNavigator.appendChild(button);
  });
}


// --------------------------------------------------------------------------
// Handle option selection
// --------------------------------------------------------------------------

function handleOptionSelect(optIdx) {

  state.selectedOptionIndex = optIdx;


  const cards =
    dom.optionsContainer.querySelectorAll(
      ".option-card"
    );


  cards.forEach((card, i) => {

    if (i === optIdx) {

      card.classList.add("selected");

      card.setAttribute(
        "aria-checked",
        "true"
      );
      card.tabIndex = 0;

    } else {

      card.classList.remove("selected");

      card.setAttribute(
        "aria-checked",
        "false"
      );
      card.tabIndex = -1;

    }

  });


  dom.btnNext.disabled = false;

}


// --------------------------------------------------------------------------
// Handle Next
// --------------------------------------------------------------------------

function handleNext() {

  if (!saveCurrentAnswer()) return;

  advanceQuestion();
}

function saveCurrentAnswer() {
  if (state.selectedOptionIndex === null) return false;
  const question = state.activeQuestions[state.currentQuestionIndex];
  state.answers[state.currentQuestionIndex] = {
    questionId: question.id,
    selectedIndex: state.selectedOptionIndex,
    correct: state.selectedOptionIndex === question.correctIndex
  };
  return true;
}

// Skipped questions count as unanswered and therefore incorrect in the score.
function handleSkip() {
  const q = state.activeQuestions[state.currentQuestionIndex];
  state.answers[state.currentQuestionIndex] = {
    questionId: q.id,
    selectedIndex: null,
    correct: false,
    skipped: true
  };
  state.selectedOptionIndex = null;
  advanceQuestion();
}

function handlePrevious() {
  if (state.currentQuestionIndex <= 0) return;
  saveCurrentAnswer();
  state.currentQuestionIndex--;
  renderQuestion();
  const savedIndex = state.answers[state.currentQuestionIndex]?.selectedIndex ?? 0;
  dom.optionsContainer.querySelectorAll(".option-card")[savedIndex]?.focus();
}

function goToQuestion(index) {
  if (index < 0 || index >= state.activeQuestions.length || index === state.currentQuestionIndex) return;
  saveCurrentAnswer();
  state.currentQuestionIndex = index;
  renderQuestion();
  dom.questionTitle.focus();
}

function advanceQuestion() {
  const nextIndex = state.currentQuestionIndex + 1;
  if (nextIndex < state.activeQuestions.length) {
    state.currentQuestionIndex = nextIndex;
    renderQuestion();
    return;
  }

  const unansweredIndex = state.activeQuestions.findIndex((_, index) => !state.answers[index]);
  if (unansweredIndex !== -1) {
    state.currentQuestionIndex = unansweredIndex;
    renderQuestion();
    dom.quizFeedback.textContent = `Question ${unansweredIndex + 1} is still unanswered. Choose an answer or skip it before finishing.`;
    dom.questionTitle.focus();
    return;
  }

  showScreen("results");
  renderResults();

}
