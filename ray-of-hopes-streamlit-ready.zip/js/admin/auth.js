// ==========================================================================
// auth.js — Admin authentication logic
// ==========================================================================

async function hasTeacherAccess(sb, userId) {
  const { data, error } = await sb.from("staff_accounts")
    .select("user_id, username")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw new Error(`Could not verify teacher access: ${error.message}`);
  return Boolean(data);
}

async function checkSession() {
  const sb = getSupabaseClient();
  if (!sb) {
    throw new Error("Database connection is unavailable. Check the Supabase settings and try again.");
  }

  const { data, error } = await sb.auth.getSession();
  if (error) throw error;
  const session = data?.session;
  if (session) {
    if (!await hasTeacherAccess(sb, session.user.id)) {
      await sb.auth.signOut();
      throw new Error("This account is not authorised for the teacher portal. Ask an administrator to grant access.");
    }
    document.getElementById("current-user").textContent = session.user.user_metadata?.username || session.user.email || session.user.phone || "Teacher";
    return true;
  }
  return false;
}

async function callTeacherAuth(payload) {
  if (!isSupabaseConfigured()) throw new Error("Database connection is unavailable. Check the Supabase settings and try again.");
  const response = await fetch(`${SUPABASE_URL}/functions/v1/teacher-auth`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "apikey": SUPABASE_ANON_KEY },
    body: JSON.stringify(payload)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || "Teacher account request failed. Please try again.");
  return result;
}

async function login(username, password) {
  const sb = getSupabaseClient();
  if (!sb) throw new Error("Database connection is unavailable. Check the Supabase settings and try again.");
  let user;
  if (username.includes("@")) {
    // Existing allowlisted teachers can keep using their previous email login.
    const { data, error } = await sb.auth.signInWithPassword({ email: username, password });
    if (error) throw error;
    user = data.user;
  } else {
    const result = await callTeacherAuth({ action: "login", username, password });
    const { data, error } = await sb.auth.setSession({ access_token: result.access_token, refresh_token: result.refresh_token });
    if (error) throw error;
    user = data.user;
  }

  try {
    if (!await hasTeacherAccess(sb, user.id)) {
      throw new Error("This account is not authorised for the teacher portal. Ask an administrator to grant access.");
    }
  } catch (accessError) {
    await sb.auth.signOut();
    throw accessError;
  }
  
  document.getElementById("current-user").textContent = user.user_metadata?.username || user.email || user.phone || username;
  return true;
}

async function registerTeacher({ username, password, phone, key }) {
  return callTeacherAuth({ action: "register", username, password, phone, key });
}

async function logout() {
  const sb = getSupabaseClient();
  if (!sb) throw new Error("Database connection is unavailable. Please reload and try again.");
  const { error } = await sb.auth.signOut();
  if (error) throw error;
  window.location.reload();
}
