// ==========================================================================
// app.js — Event listeners & initialization
//
// This is the entry point. It wires up all user interactions using
// addEventListener (no inline onclick). Loaded last, after all other
// modules are available.
// ==========================================================================

// ── Education level definitions ──
// These are rendered as clickable cards on the level-selection screen.
const EDUCATION_LEVELS = [
  {
    key: "primary",
    label: "Up to 5th Standard",
    description: "Basic reading, writing, and simple arithmetic",
    icon: "📒"
  },
  {
    key: "middle",
    label: "6th – 8th Standard",
    description: "Knows parts of a computer, basic grammar, fractions",
    icon: "📗"
  },
  {
    key: "secondary",
    label: "9th – 10th Standard",
    description: "OS concepts, comprehension, word problems",
    icon: "📘"
  },
  {
    key: "higher",
    label: "11th – 12th Standard",
    description: "Networking basics, formal English, percentages",
    icon: "📕"
  },
  {
    key: "graduate",
    label: "Graduate & Above",
    description: "Software concepts, business English, data interpretation",
    icon: "🎓"
  }
];

const SUPPORT_CHOICES = [
  { key: "large-text", title: "Larger text", detail: "Make question text and choices easier to read.", categories: ["Visual"] },
  { key: "high-contrast", title: "High contrast", detail: "Use stronger text and control contrast.", categories: ["Visual"] },
  { key: "keyboard", title: "Keyboard-friendly controls", detail: "Keep clear focus and use keyboard to select answers.", categories: ["Visual", "Locomotor"] },
  { key: "plain-instructions", title: "Short, clear instructions", detail: "Show brief guidance and a clear progress reminder.", categories: ["Cognitive/Intellectual"] },
  { key: "text-alerts", title: "Text for all alerts", detail: "Keep important instructions and status messages visible in text.", categories: ["Hearing"] }
];

function renderSupportOptions(category) {
  dom.supportOptions.replaceChildren();
  const recommended = SUPPORT_CHOICES.filter(choice => choice.categories.includes(category)).map(choice => choice.key);
  SUPPORT_CHOICES.forEach(choice => {
    const label = document.createElement("label");
    label.className = "support-toggle";
    const input = document.createElement("input");
    input.type = "checkbox";
    input.value = choice.key;
    input.checked = recommended.includes(choice.key);
    input.dataset.support = choice.key;
    const text = document.createElement("span");
    const title = document.createElement("strong");
    title.textContent = choice.title;
    const detail = document.createElement("small");
    detail.textContent = choice.detail;
    text.append(title, detail);
    label.append(input, text);
    dom.supportOptions.append(label);
  });
  dom.supportReadAloud.disabled = !("speechSynthesis" in window && "SpeechSynthesisUtterance" in window);
  dom.supportReadAloud.checked = category === "Visual";
  if (dom.supportReadAloud.disabled) dom.supportReadAloud.checked = false;
  document.getElementById("read-aloud-help").textContent = dom.supportReadAloud.disabled
    ? "Read-aloud is not available in this browser. Other accessibility supports still work."
    : "Use your browser’s built-in speech voice. You can stop it at any time.";
}

function applySupports() {
  document.body.classList.toggle("support-large-text", state.supports.includes("large-text"));
  document.body.classList.toggle("support-high-contrast", state.supports.includes("high-contrast"));
  document.body.classList.toggle("support-plain", state.supports.includes("plain-instructions"));
  document.body.classList.toggle("support-keyboard", state.supports.includes("keyboard"));
  dom.btnReadAloud.hidden = !state.readAloud || !("speechSynthesis" in window && "SpeechSynthesisUtterance" in window);
  dom.btnStopReading.hidden = true;
  const instructions = document.getElementById("quiz-instructions");
  instructions.textContent = state.supports.includes("plain-instructions")
    ? "Choose one answer. Skip any question if you want to move on. There is no time limit."
    : "Choose one answer, or skip a question and return later. This assessment has no time limit.";
}

/**
 * Render the education level selection cards.
 */
function renderLevelCards() {
  dom.levelCardsContainer.innerHTML = "";

  EDUCATION_LEVELS.forEach((lvl) => {
    const card = document.createElement("button");
    card.type = "button";
    card.className =
      "level-card w-full text-left border-2 border-gray-300 rounded-xl px-5 py-4 " +
      "flex items-center gap-4 cursor-pointer";
    card.setAttribute("role", "radio");
    card.setAttribute("aria-checked", "false");
    card.setAttribute("data-level", lvl.key);

    card.innerHTML = `
      <span class="text-3xl" aria-hidden="true">${lvl.icon}</span>
      <div>
        <p class="text-base sm:text-lg font-semibold text-gray-900">${lvl.label}</p>
        <p class="text-sm text-gray-500">${lvl.description}</p>
      </div>
    `;

    card.addEventListener("click", () => {
      // Deselect all
      dom.levelCardsContainer.querySelectorAll(".level-card").forEach(c => {
        c.classList.remove("selected");
        c.setAttribute("aria-checked", "false");
      });
      // Select this one
      card.classList.add("selected");
      card.setAttribute("aria-checked", "true");

      state.educationLevel = lvl.key;
      state.educationLevelLabel = lvl.label;
      dom.btnBeginQuiz.disabled = false;
      dom.levelHint.textContent = `${lvl.label} selected — ready to begin!`;
    });

    dom.levelCardsContainer.appendChild(card);
  });
}

// ==========================================================================
// ── Welcome Form: enable Start button when name is filled ──
// ==========================================================================
dom.nameInput.addEventListener("input", () => {
  const hasName = dom.nameInput.value.trim().length > 0;
  dom.btnStart.disabled = !hasName;
  if (hasName) {
    dom.nameError.classList.add("hidden");
    dom.startHint.textContent = "You're ready!";
  } else {
    dom.startHint.textContent = "Fill in your name above to begin.";
  }
});

// ==========================================================================
// ── Role choice ──
document.getElementById("btn-role-student").addEventListener("click", () => showScreen("welcome"));

// ── Welcome Form submission → support preferences ──
// ==========================================================================
dom.welcomeForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const name = dom.nameInput.value.trim();
  if (!name) {
    dom.nameError.classList.remove("hidden");
    dom.nameInput.focus();
    return;
  }

  // Capture user info
  state.fullName = name;
  state.category = dom.categorySelect.value;
  state.accommodationNotes = dom.accommodationInput.value.trim();

  // Render level cards and transition
  renderSupportOptions(state.category);
  showScreen("support");
});

document.getElementById("btn-support-back").addEventListener("click", () => showScreen("welcome"));
document.getElementById("btn-support-continue").addEventListener("click", () => {
  state.supports = [...dom.supportOptions.querySelectorAll("input[data-support]:checked")].map(input => input.value);
  state.readAloud = dom.supportReadAloud.checked;
  applySupports();
  renderLevelCards();
  showScreen("level");
});

dom.btnReadAloud.addEventListener("click", () => {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const question = state.activeQuestions[state.currentQuestionIndex];
  const options = question.options.map((option, index) => `Option ${index + 1}: ${option}`).join(". ");
  const utterance = new SpeechSynthesisUtterance(`${question.question}. ${options}`);
  utterance.onstart = () => { dom.btnStopReading.hidden = false; };
  utterance.onend = () => { dom.btnStopReading.hidden = true; };
  window.speechSynthesis.speak(utterance);
});
dom.btnStopReading.addEventListener("click", () => {
  window.speechSynthesis?.cancel();
  dom.btnStopReading.hidden = true;
});

// ==========================================================================
// ── Begin Quiz button → load questions and start ──
// ==========================================================================
dom.btnBeginQuiz.addEventListener("click", async () => {
  if (!state.educationLevel) return;

  const prevText = dom.btnBeginQuiz.textContent;
  dom.btnBeginQuiz.disabled = true;
  dom.btnBeginQuiz.innerHTML = `
    <svg class="animate-spin h-5 w-5 text-white inline mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
    </svg>
    Loading...
  `;

  try {
    state.activeQuestions = await selectRandomQuestions(state.educationLevel, 4);
    state.currentQuestionIndex = 0;
    state.answers = [];
    state.selectedOptionIndex = null;
    showScreen("quiz");
    renderQuestion();
  } catch (error) {
    console.error("Could not load assessment questions:", error);
    alert(`Could not start the assessment. ${error.message || "Please try again or contact staff."}`);
  } finally {
    dom.btnBeginQuiz.textContent = prevText;
    dom.btnBeginQuiz.disabled = false;
  }
});

// ==========================================================================
// ── Next button ──
// ==========================================================================
dom.btnNext.addEventListener("click", handleNext);
dom.btnSkip.addEventListener("click", handleSkip);
dom.btnPrevious.addEventListener("click", handlePrevious);

// Return to the welcome screen and clear the current assessment.
dom.btnHome.addEventListener("click", () => {
  const assessmentInProgress =
    screens.quiz.classList.contains("active") ||
    screens.results.classList.contains("active");
  if (assessmentInProgress && !window.confirm("Return home? Your assessment progress and results will be cleared.")) {
    return;
  }

  resetState();
  window.speechSynthesis?.cancel();
  document.body.classList.remove("support-large-text", "support-high-contrast", "support-plain", "support-keyboard");
  dom.nameInput.value = "";
  dom.categorySelect.value = "None/Other";
  dom.accommodationInput.value = "";
  dom.nameError.classList.add("hidden");
  dom.btnStart.disabled = true;
  dom.startHint.textContent = "Fill in your name above to begin.";
  dom.btnBeginQuiz.disabled = true;
  dom.levelHint.textContent = "Select your education level above to continue.";
  showScreen("role");
});

// ==========================================================================
// ── Submit button ──
// ==========================================================================
dom.btnSubmit.addEventListener("click", submitToSupabase);
document.getElementById("btn-print-results").addEventListener("click", () => window.print());

// ==========================================================================
// ── Restart button ──
// ==========================================================================
dom.btnRestart.addEventListener("click", () => {
  resetState();
  window.speechSynthesis?.cancel();
  document.body.classList.remove("support-large-text", "support-high-contrast", "support-plain", "support-keyboard");

  // Reset form fields
  dom.nameInput.value = "";
  dom.categorySelect.value = "None/Other";
  dom.accommodationInput.value = "";
  dom.btnStart.disabled = true;
  dom.startHint.textContent = "Fill in your name above to begin.";
  dom.btnBeginQuiz.disabled = true;
  dom.levelHint.textContent = "Select your education level above to continue.";

  showScreen("role");
});

// ==========================================================================
// ── Keyboard shortcut: Enter advances only when the quiz region has focus ──
// Enter on answer choices and navigation buttons keeps its normal behavior.
// ==========================================================================
document.addEventListener("keydown", (e) => {
  if (
    e.key === "Enter" &&
    !e.repeat &&
    screens.quiz.classList.contains("active") &&
    (e.target === screens.quiz || e.target === document.body) &&
    !dom.btnNext.disabled
  ) {
    e.preventDefault();
    dom.btnNext.click();
  }
});
