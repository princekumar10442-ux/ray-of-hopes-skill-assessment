// ==========================================================================
// questions-manager.js — CRUD logic for questions
// ==========================================================================

let questionModalPreviousFocus = null;

async function loadQuestions() {
  const sb = getSupabaseClient();
  const tbody = document.getElementById("questions-tbody");
  const status = document.getElementById("questions-status");
  
  const level = document.getElementById("qfilter-level").value;
  const section = document.getElementById("qfilter-section").value;
  
  status.textContent = "Loading...";
  tbody.innerHTML = "";
  if (!sb) {
    status.textContent = "Database connection is unavailable. Check the Supabase settings.";
    return;
  }
  
  try {
    const { data, error } = await sb
      .from("questions")
      .select("*")
      .eq("education_level", level)
      .eq("section", section)
      .order("created_at", { ascending: false });
      
    if (error) throw error;
    
    if (data.length === 0) {
      status.textContent = "No questions found for this level and section.";
      return;
    }
    
    status.textContent = "";
    
    data.forEach(q => {
      const tr = document.createElement("tr");
      tr.className = `hover:bg-gray-50 ${!q.is_active ? 'opacity-50' : ''}`;

      const questionCell = document.createElement("td");
      questionCell.className = "p-3";
      const questionText = document.createElement("div");
      questionText.className = "font-medium text-gray-900 break-words";
      questionText.textContent = q.question || "";
      questionCell.appendChild(questionText);
      if (!q.is_active) {
        const inactive = document.createElement("span");
        inactive.className = "inline-flex mt-1 items-center px-2 py-0.5 rounded text-xs font-medium bg-red-100 text-red-800";
        inactive.textContent = "Inactive";
        questionCell.appendChild(inactive);
      }
      tr.appendChild(questionCell);

      const optionsCell = document.createElement("td");
      optionsCell.className = "p-3";
      let options = q.options;
      if (typeof options === "string") {
        try { options = JSON.parse(options); } catch { options = []; }
      }
      options = Array.isArray(options) ? options : [];
      options.forEach((option, index) => {
        const item = document.createElement("div");
        item.className = `${index === q.correct_index ? "font-bold text-green-600" : "text-gray-600"} text-xs`;
        item.textContent = `${index === q.correct_index ? "✓" : "•"} ${option}`;
        optionsCell.appendChild(item);
      });
      tr.appendChild(optionsCell);

      const actionsCell = document.createElement("td");
      actionsCell.className = "p-3 text-right space-x-2";
      const editButton = document.createElement("button");
      editButton.type = "button";
      editButton.className = "text-blue-600 hover:text-blue-800 font-medium";
      editButton.textContent = "Edit";
      editButton.addEventListener("click", () => openModal(q.id));
      const activeButton = document.createElement("button");
      activeButton.type = "button";
      activeButton.className = "text-gray-600 hover:text-gray-800 font-medium";
      activeButton.textContent = q.is_active ? "Disable" : "Enable";
      activeButton.addEventListener("click", () => toggleActive(q.id, !q.is_active));
      actionsCell.append(editButton, activeButton);
      tr.appendChild(actionsCell);
      tbody.appendChild(tr);
    });
    
  } catch (err) {
    console.error("Questions error:", err);
    status.textContent = `Could not load questions: ${err.message || "Please try again."}`;
  }
}
function openModal(questionId = null) {
  const modal = document.getElementById("question-modal");
  const form = document.getElementById("question-form");
  const title = document.getElementById("modal-title");
  questionModalPreviousFocus = document.activeElement;
  const modalStatus = document.getElementById("modal-status");
  modalStatus.className = "hidden text-sm";
  modalStatus.textContent = "";
  const saveButton = document.getElementById("btn-modal-save");
  
  form.reset();
  
  // Pre-fill filter selections
  document.getElementById("modal-level").value = document.getElementById("qfilter-level").value;
  document.getElementById("modal-section").value = document.getElementById("qfilter-section").value;
  
  if (questionId) {
    title.textContent = "Edit Question";
    document.getElementById("modal-id").value = questionId;
    saveButton.disabled = true;
    saveButton.textContent = "Loading…";
    fetchAndFillModal(questionId);
  } else {
    title.textContent = "Add Question";
    document.getElementById("modal-id").value = "";
    saveButton.disabled = false;
    saveButton.textContent = "Save Question";
  }
  
  modal.classList.remove("hidden");
  modal.classList.add("flex");
  document.getElementById("modal-level").focus();
}

function closeModal() {
  const modal = document.getElementById("question-modal");
  modal.classList.add("hidden");
  modal.classList.remove("flex");
  questionModalPreviousFocus?.focus();
  questionModalPreviousFocus = null;
}

async function fetchAndFillModal(id) {
  const sb = getSupabaseClient();
  const status = document.getElementById("modal-status");
  try {
    if (!sb) throw new Error("Database connection is unavailable.");
    const { data, error } = await sb.from("questions").select("*").eq("id", id).single();
    if (error) throw error;
    if (!data) throw new Error("This question could not be found.");
  
  document.getElementById("modal-level").value = data.education_level;
  document.getElementById("modal-section").value = data.section;
  document.getElementById("modal-question").value = data.question;
  
  const optInputs = document.querySelectorAll(".modal-opt");
  let options = data.options;
  if (typeof options === "string") {
    try { options = JSON.parse(options); } catch { options = []; }
  }
  (Array.isArray(options) ? options : []).forEach((opt, i) => {
    if(optInputs[i]) optInputs[i].value = opt;
  });
  
  const radios = document.getElementsByName("modal-correct");
  if(radios[data.correct_index]) {
    radios[data.correct_index].checked = true;
  }
  document.getElementById("btn-modal-save").disabled = false;
  document.getElementById("btn-modal-save").textContent = "Save Question";
  } catch (error) {
    status.textContent = `Could not load question: ${error.message || "Please try again."}`;
    status.className = "text-sm text-red-700";
    document.getElementById("btn-modal-save").disabled = false;
    document.getElementById("btn-modal-save").textContent = "Save Question";
  }
}

function showQuestionModalStatus(message, isError = false) {
  const status = document.getElementById("modal-status");
  status.textContent = message;
  status.className = `text-sm ${isError ? "text-red-700" : "text-green-700"}`;
}

async function saveQuestion(e) {
  e.preventDefault();
  const sb = getSupabaseClient();
  if (!sb) {
    showQuestionModalStatus("Database connection is unavailable. Check the Supabase settings and try again.", true);
    return;
  }
  
  const id = document.getElementById("modal-id").value;
  const level = document.getElementById("modal-level").value;
  const section = document.getElementById("modal-section").value;
  const question = document.getElementById("modal-question").value;
  
  const options = Array.from(document.querySelectorAll(".modal-opt")).map(i => i.value.trim());
  const correctInput = document.querySelector('input[name="modal-correct"]:checked');
  if (!correctInput || options.some(option => !option)) {
    showQuestionModalStatus("Enter all answer choices and select the correct answer.", true);
    return;
  }
  const correct_index = parseInt(correctInput.value, 10);
  
  const payload = {
    education_level: level,
    section: section,
    question: question,
    options: options,
    correct_index: correct_index
  };
  
  try {
    const saveButton = document.getElementById("btn-modal-save");
    saveButton.disabled = true;
    saveButton.textContent = "Saving…";
    let error;
    if (id) {
      ({ error } = await sb.from("questions").update(payload).eq("id", id));
    } else {
      payload.is_active = true;
      ({ error } = await sb.from("questions").insert(payload));
    }
    if (error) throw error;
    closeModal();
    await loadQuestions();
  } catch (error) {
    console.error("Could not save question:", error);
    showQuestionModalStatus(`Could not save question: ${error.message || "Please try again."}`, true);
  } finally {
    const saveButton = document.getElementById("btn-modal-save");
    saveButton.disabled = false;
    saveButton.textContent = "Save Question";
  }
}

async function toggleActive(id, newState) {
  try {
    const sb = getSupabaseClient();
    if (!sb) throw new Error("Database unavailable");
    const { error } = await sb.from("questions").update({ is_active: newState }).eq("id", id);
    if (error) throw error;
    await loadQuestions();
  } catch (error) {
    console.error("Could not update question status:", error);
    document.getElementById("questions-status").textContent = `Could not update question: ${error.message || "Please try again."}`;
  }
}
