import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function reply(status: number, body: Record<string, unknown>, extraHeaders: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, ...extraHeaders, "Content-Type": "application/json" },
  });
}

function keysMatch(supplied: string, expected: string): boolean {
  const a = new TextEncoder().encode(supplied);
  const b = new TextEncoder().encode(expected);
  let diff = a.length ^ b.length;
  const length = Math.max(a.length, b.length);
  for (let i = 0; i < length; i++) diff |= (a[i] ?? 0) ^ (b[i] ?? 0);
  return diff === 0;
}

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return reply(405, { error: "Method not allowed." });

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const registrationKey = Deno.env.get("TEACHER_REGISTRATION_KEY");
  if (!supabaseUrl || !serviceKey || !anonKey || !registrationKey) {
    return reply(503, { error: "Teacher account service is not configured yet." });
  }

  let input: Record<string, unknown>;
  try {
    input = await request.json();
  } catch {
    return reply(400, { error: "Please submit valid account details." });
  }

  const admin = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const action = input.action;
  if (action !== "register" && action !== "login") return reply(400, { error: "Unknown teacher account action." });

  const clientIp = request.headers.get("cf-connecting-ip")
    || request.headers.get("x-real-ip")
    || request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  if (!clientIp) return reply(503, { error: "Teacher account service could not verify this request. Please try again." });
  const bucketBytes = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`${action}:${clientIp}:${registrationKey}`),
  );
  const bucketHash = Array.from(new Uint8Array(bucketBytes), byte => byte.toString(16).padStart(2, "0")).join("");
  const { data: allowed, error: rateLimitError } = await admin.rpc("consume_teacher_auth_attempt", {
    p_bucket_hash: bucketHash,
    p_limit: 20,
    p_window_seconds: 900,
  });
  if (rateLimitError) return reply(503, { error: "Teacher account service is not fully configured yet." });
  if (!allowed) return reply(429, { error: "Too many attempts. Please wait 15 minutes and try again." }, { "Retry-After": "900" });

  if (action === "register") {
    const username = typeof input.username === "string" ? input.username.trim().toLowerCase() : "";
    const password = typeof input.password === "string" ? input.password : "";
    const phone = typeof input.phone === "string" ? input.phone.trim() : "";
    const key = typeof input.key === "string" ? input.key : "";

    if (!keysMatch(key, registrationKey)) return reply(403, { error: "The registration key is not valid." });
    if (!/^[a-z0-9._-]{3,32}$/.test(username)) return reply(400, { error: "Use a username with 3–32 letters, numbers, dots, underscores or hyphens." });
    if (password.length < 8 || password.length > 128) return reply(400, { error: "Choose a password between 8 and 128 characters." });
    if (!/^\+[1-9]\d{7,14}$/.test(phone)) return reply(400, { error: "Enter a phone number with country code, such as +919876543210." });

    const { data: existing, error: lookupError } = await admin.from("staff_accounts")
      .select("user_id").or(`username.eq.${username},phone.eq.${phone}`).limit(1);
    if (lookupError) return reply(500, { error: "Could not check account availability. Please try again." });
    if (existing?.length) return reply(409, { error: "That username or phone number is already registered." });

    // The registration key authorizes account creation. The phone is stored as contact/login data;
    // phone ownership is not independently verified by this flow.
    const { data: created, error: createError } = await admin.auth.admin.createUser({
      phone,
      password,
      phone_confirm: true,
      user_metadata: { username },
    });
    if (createError || !created.user) {
      return reply(400, { error: "Could not create this account. Check that the phone number is unused and try again." });
    }

    const { error: insertError } = await admin.from("staff_accounts").insert({
      user_id: created.user.id,
      username,
      phone,
    });
    if (insertError) {
      await admin.auth.admin.deleteUser(created.user.id);
      if (insertError.code === "23505") return reply(409, { error: "That username or phone number is already registered." });
      return reply(500, { error: "Could not finish account setup. Please try again." });
    }
    return reply(201, { ok: true, username });
  }

  if (action === "login") {
    const username = typeof input.username === "string" ? input.username.trim().toLowerCase() : "";
    const password = typeof input.password === "string" ? input.password : "";
    if (!/^[a-z0-9._-]{3,32}$/.test(username) || !password) {
      return reply(400, { error: "Enter your username and password." });
    }
    const { data: staff, error: lookupError } = await admin.from("staff_accounts")
      .select("phone").eq("username", username).maybeSingle();
    if (lookupError || !staff?.phone) return reply(401, { error: "Incorrect username or password." });

    const publicClient = createClient(supabaseUrl, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data, error } = await publicClient.auth.signInWithPassword({ phone: staff.phone, password });
    if (error || !data.session) return reply(401, { error: "Incorrect username or password." });
    return reply(200, {
      access_token: data.session.access_token,
      refresh_token: data.session.refresh_token,
    });
  }

});
