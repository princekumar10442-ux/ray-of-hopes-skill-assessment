// ==========================================================================
// dashboard.js — Logic for fetching and displaying submissions
// ==========================================================================

const DASHBOARD_PAGE_SIZE = 25;
let dashboardPage = 0;
let dashboardRequestId = 0;

async function loadDashboard() {
  const requestId = ++dashboardRequestId;
  const sb = getSupabaseClient();
  const tbody = document.getElementById("dashboard-tbody");
  const status = document.getElementById("dashboard-status");
  const countMetric = document.getElementById("metric-assessments");
  const averageMetric = document.getElementById("metric-average");
  const latestMetric = document.getElementById("metric-latest");
  
  const nameFilter = document.getElementById("filter-name").value.trim();
  const levelFilter = document.getElementById("filter-level").value;
  
  status.textContent = "Loading...";
  tbody.innerHTML = "";
  countMetric.textContent = "—";
  averageMetric.textContent = "—";
  latestMetric.textContent = "—";

  if (!sb) {
    status.textContent = "Database connection is unavailable. Check the Supabase settings.";
    return;
  }
  
  try {
    let query = sb.from("assessments").select("*", { count: "exact" })
      .order("created_at", { ascending: false })
      .range(dashboardPage * DASHBOARD_PAGE_SIZE, (dashboardPage + 1) * DASHBOARD_PAGE_SIZE - 1);
    
    if (nameFilter) {
      query = query.ilike("full_name", `%${nameFilter}%`);
    }
    if (levelFilter) {
      query = query.eq("education_level", levelFilter);
    }
    
    const { data, error, count } = await query;
    if (error) throw error;
    if (requestId !== dashboardRequestId) return;

    const totalCount = count ?? data.length;
    const pageCount = Math.ceil(totalCount / DASHBOARD_PAGE_SIZE);
    if (pageCount && dashboardPage >= pageCount) {
      dashboardPage = pageCount - 1;
      loadDashboard();
      return;
    }
    
    if (data.length === 0) {
      countMetric.textContent = "0";
      averageMetric.textContent = "—";
      latestMetric.textContent = "—";
      status.textContent = "No assessments match these filters. Try clearing or changing your search.";
      updateDashboardPagination(0, 0);
      return;
    }

    countMetric.textContent = String(totalCount);
    const average = data.reduce((sum, record) => {
      const total = Number(record.total_questions);
      const score = Number(record.score);
      return sum + (total > 0 && Number.isFinite(score) ? score / total * 100 : 0);
    }, 0) / data.length;
    averageMetric.textContent = `${Math.round(average)}%`;
    const pageNumber = dashboardPage + 1;
    latestMetric.textContent = `${pageNumber} of ${pageCount}`;
    const firstRecord = dashboardPage * DASHBOARD_PAGE_SIZE + 1;
    const lastRecord = firstRecord + data.length - 1;
    status.textContent = `Showing ${firstRecord}–${lastRecord} of ${totalCount} matching assessments.`;
    updateDashboardPagination(pageNumber, pageCount);
    
    data.forEach(sub => {
      const tr = document.createElement("tr");
      tr.className = "hover:bg-gray-50";
      
      const timestamp = new Date(sub.created_at);
      const date = Number.isNaN(timestamp.getTime())
        ? "Unknown date"
        : timestamp.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
      const totalQuestions = Number(sub.total_questions);
      const scorePct = totalQuestions > 0
        ? Math.round((Number(sub.score) / totalQuestions) * 100)
        : 0;

      const addCell = (value, className = "p-3") => {
        const cell = document.createElement("td");
        cell.className = className;
        cell.textContent = value == null ? "" : String(value);
        tr.appendChild(cell);
        return cell;
      };

      addCell(date);
      addCell(sub.full_name, "p-3 font-medium text-gray-900");
      addCell(sub.education_level, "p-3 capitalize");
      addCell(sub.category);
      const supports = (sub.accommodation_notes || "").trim();
      addCell(supports || "None recorded", "p-3 whitespace-normal min-w-[180px] max-w-xs text-gray-600");
      const scoreCell = addCell("");
      const scoreBadge = document.createElement("span");
      scoreBadge.className = `inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${scorePct >= 60 ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`;
      scoreBadge.textContent = `${sub.score}/${sub.total_questions} (${scorePct}%)`;
      scoreCell.appendChild(scoreBadge);
      const pathwayCell = addCell("", "p-3 text-xs text-gray-600 min-w-[180px] max-w-xs whitespace-normal");
      const pathwayText = document.createElement("span");
      pathwayText.textContent = sub.recommended_pathway || "";
      pathwayCell.appendChild(pathwayText);
      if (sub.section_breakdown && typeof sub.section_breakdown === "object") {
        const details = document.createElement("details");
        details.className = "mt-2";
        const summary = document.createElement("summary");
        summary.className = "cursor-pointer font-semibold";
        summary.textContent = "Section scores";
        const breakdown = document.createElement("div");
        breakdown.className = "mt-1 space-y-1";
        Object.entries(sub.section_breakdown).forEach(([section, score]) => {
          const line = document.createElement("p");
          line.textContent = `${section}: ${score?.correct ?? 0}/${score?.total ?? 0}`;
          breakdown.appendChild(line);
        });
        details.append(summary, breakdown);
        pathwayCell.appendChild(details);
      }
      pathwayCell.title = sub.recommended_pathway || "";
      tbody.appendChild(tr);
    });
    
  } catch (err) {
    if (requestId !== dashboardRequestId) return;
    console.error("Dashboard error:", err);
    status.textContent = `Could not load submissions: ${err.message || "Please check the connection and try again."}`;
  }
}

function updateDashboardPagination(pageNumber, pageCount) {
  document.getElementById("dashboard-page-info").textContent = pageCount
    ? `Page ${pageNumber} of ${pageCount}`
    : "No results";
  document.getElementById("btn-page-previous").disabled = pageNumber <= 1;
  document.getElementById("btn-page-next").disabled = pageNumber >= pageCount;
}

async function exportCSV() {
  const sb = getSupabaseClient();
  if (!sb) {
    alert("The database is unavailable. Check your connection and try again.");
    return;
  }
  // Fetch all matching filters without limit
  const nameFilter = document.getElementById("filter-name").value.trim();
  const levelFilter = document.getElementById("filter-level").value;
  
  try {
    const pageSize = 1000;
    const data = [];
    for (let offset = 0; ; offset += pageSize) {
      let query = sb.from("assessments").select("*")
        .order("created_at", { ascending: false })
        .range(offset, offset + pageSize - 1);
      if (nameFilter) query = query.ilike("full_name", `%${nameFilter}%`);
      if (levelFilter) query = query.eq("education_level", levelFilter);

      const { data: page, error } = await query;
      if (error) throw error;
      data.push(...(page || []));
      if (!page || page.length < pageSize) break;
    }

    const csvCell = (value) => {
      let text = String(value ?? "");
      if (/^[\s]*[=+@-]/.test(text)) text = `'${text}`;
      return `"${text.replace(/"/g, '""')}"`;
    };
    const headers = ["Date", "Name", "Category", "Selected Supports / Notes", "Education Level", "Score", "Total", "Percent", "Section Breakdown", "Pathway"];
    const csvRows = [headers.map(csvCell).join(",")];

    data.forEach(r => {
      const row = [
        Number.isNaN(new Date(r.created_at).getTime()) ? "" : new Date(r.created_at).toISOString(),
        r.full_name,
        r.category,
        r.accommodation_notes || "",
        r.education_level,
        r.score,
        r.total_questions,
        Number(r.total_questions) > 0 ? `${Math.round(Number(r.score) / Number(r.total_questions) * 100)}%` : "",
        r.section_breakdown ? JSON.stringify(r.section_breakdown) : "",
        r.recommended_pathway
      ];
      csvRows.push(row.map(csvCell).join(","));
    });

    const blob = new Blob([csvRows.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = window.URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.hidden = true;
    anchor.href = url;
    anchor.download = "assessments.csv";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
  } catch (error) {
    console.error("CSV export failed:", error);
    alert("Could not export assessments. Please try again.");
  }
}
