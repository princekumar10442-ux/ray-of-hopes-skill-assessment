// ==========================================================================
// admin-app.js — Admin Panel Initialization & Event Listeners
// ==========================================================================

document.addEventListener("DOMContentLoaded", async () => {
  const loginScreen = document.getElementById("screen-login");
  const adminScreen = document.getElementById("screen-admin");
  const authControls = document.getElementById("auth-controls");
  const errorEl = document.getElementById("login-error");
  const registerError = document.getElementById("register-error");
  const skipLink = document.getElementById("admin-skip-link");

  const showLogin = (message = "") => {
    adminScreen.classList.remove("active");
    adminScreen.classList.add("hidden");
    loginScreen.classList.add("active");
    authControls.classList.add("hidden");
    skipLink.href = "#screen-login";
    document.getElementById("login-form").classList.remove("hidden");
    document.getElementById("register-form").classList.add("hidden");
    if (message) {
      errorEl.textContent = message;
      errorEl.classList.remove("hidden");
    }
  };
  const showTeacherPortal = () => {
    loginScreen.classList.remove("active");
    adminScreen.classList.remove("hidden");
    adminScreen.classList.add("active");
    authControls.classList.remove("hidden");
    skipLink.href = "#screen-admin";
  };

  try {
    if (await checkSession()) {
      showTeacherPortal();
      loadDashboard();
    } else {
      showLogin();
    }
  } catch (error) {
    showLogin(error.message || "Could not check your sign-in. Please try again.");
  }

  // Login form
  document.getElementById("login-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("btn-login");
    const errorEl = document.getElementById("login-error");
    
    btn.disabled = true;
    btn.textContent = "Signing in...";
    errorEl.classList.add("hidden");
    
    try {
      const username = document.getElementById("login-username").value.trim();
      const pass = document.getElementById("login-password").value;
      
      await login(username, pass);
      
      // Success
      showTeacherPortal();
      loadDashboard();
      
    } catch (err) {
      errorEl.textContent = err.message || "Login failed";
      errorEl.classList.remove("hidden");
    } finally {
      btn.disabled = false;
      btn.textContent = "Sign In";
    }
  });

  const setAuthMode = (mode) => {
    const registering = mode === "register";
    document.getElementById("login-form").classList.toggle("hidden", registering);
    document.getElementById("register-form").classList.toggle("hidden", !registering);
    document.getElementById("auth-mode-login").classList.toggle("active", !registering);
    document.getElementById("auth-mode-register").classList.toggle("active", registering);
    document.getElementById("auth-mode-login").setAttribute("aria-selected", String(!registering));
    document.getElementById("auth-mode-register").setAttribute("aria-selected", String(registering));
    errorEl.classList.add("hidden");
    registerError.classList.add("hidden");
    document.getElementById("auth-message").classList.add("hidden");
  };
  document.getElementById("auth-mode-login").addEventListener("click", () => setAuthMode("login"));
  document.getElementById("auth-mode-register").addEventListener("click", () => setAuthMode("register"));
  document.getElementById("register-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const button = document.getElementById("btn-register");
    const username = document.getElementById("register-username").value.trim();
    const password = document.getElementById("register-password").value;
    const phone = document.getElementById("register-phone").value.trim();
    const key = document.getElementById("register-key").value;
    button.disabled = true;
    button.textContent = "Creating account…";
    registerError.classList.add("hidden");
    try {
      await registerTeacher({ username, password, phone, key });
      await login(username, password);
      showTeacherPortal();
      loadDashboard();
    } catch (error) {
      registerError.textContent = error.message || "Could not create the teacher account.";
      registerError.classList.remove("hidden");
    } finally {
      button.disabled = false;
      button.textContent = "Create teacher account";
    }
  });

  // Logout
  document.getElementById("btn-logout").addEventListener("click", async () => {
    try {
      await logout();
    } catch (error) {
      const status = document.getElementById("dashboard-status");
      status.textContent = error.message || "Could not sign out. Please try again.";
    }
  });

  // Tabs
  const tabButtons = [...document.querySelectorAll(".tab-btn")];
  tabButtons.forEach((btn, index) => {
    btn.addEventListener("click", (e) => {
      const tabButton = e.currentTarget;
      // Update buttons
      document.querySelectorAll(".tab-btn").forEach(b => {
        b.classList.remove("active");
        b.setAttribute("aria-selected", "false");
        b.tabIndex = -1;
      });
      tabButton.classList.add("active");
      tabButton.setAttribute("aria-selected", "true");
      tabButton.tabIndex = 0;
      
      // Update content
      document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active", "block"));
      document.querySelectorAll(".tab-content").forEach(c => c.classList.add("hidden"));
      
      const tabId = tabButton.getAttribute("data-tab");
      document.getElementById(`tab-${tabId}`).classList.remove("hidden");
      document.getElementById(`tab-${tabId}`).classList.add("active", "block");
      
      // Load data
      if (tabId === "dashboard") loadDashboard();
      if (tabId === "questions") loadQuestions();
    });
    btn.addEventListener("keydown", (event) => {
      const direction = event.key === "ArrowRight" ? 1 : event.key === "ArrowLeft" ? -1 : 0;
      const targetIndex = event.key === "Home" ? 0 : event.key === "End" ? tabButtons.length - 1
        : (index + direction + tabButtons.length) % tabButtons.length;
      if (!direction && event.key !== "Home" && event.key !== "End") return;
      event.preventDefault();
      tabButtons[targetIndex].focus();
      tabButtons[targetIndex].click();
    });
  });

  // Dashboard filters
  document.getElementById("btn-refresh-dashboard").addEventListener("click", loadDashboard);
  document.getElementById("filter-level").addEventListener("change", () => {
    dashboardPage = 0;
    loadDashboard();
  });
  let searchTimer;
  document.getElementById("filter-name").addEventListener("input", () => {
    window.clearTimeout(searchTimer);
    searchTimer = window.setTimeout(() => {
      dashboardPage = 0;
      loadDashboard();
    }, 250);
  });
  document.getElementById("btn-page-previous").addEventListener("click", () => {
    if (dashboardPage > 0) { dashboardPage--; loadDashboard(); }
  });
  document.getElementById("btn-page-next").addEventListener("click", () => {
    dashboardPage++;
    loadDashboard();
  });

  document.getElementById("btn-export-csv").addEventListener("click", exportCSV);

  // Questions filters
  document.getElementById("qfilter-level").addEventListener("change", loadQuestions);
  document.getElementById("qfilter-section").addEventListener("change", loadQuestions);

  // Modal logic
  document.getElementById("btn-add-question").addEventListener("click", () => openModal(null));
  document.getElementById("btn-modal-cancel").addEventListener("click", closeModal);
  document.getElementById("question-form").addEventListener("submit", saveQuestion);
  
  // Close modal on outside click
  document.getElementById("question-modal").addEventListener("click", (e) => {
    if (e.target.id === "question-modal") closeModal();
  });
  document.getElementById("question-modal").addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      event.preventDefault();
      closeModal();
      return;
    }
    if (event.key !== "Tab") return;
    const modal = document.getElementById("question-modal");
    const focusable = [...modal.querySelectorAll('button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [href], [tabindex]:not([tabindex="-1"])')]
      .filter(element => !element.hidden);
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

});
