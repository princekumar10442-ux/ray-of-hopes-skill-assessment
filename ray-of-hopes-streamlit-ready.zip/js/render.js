// ==========================================================================
// render.js — DOM references & screen management
//
// Caches DOM elements once on load and provides the showScreen() utility
// used by all other modules.
// ==========================================================================

const $ = (sel) => document.querySelector(sel);

// ── Screen containers ──
const screens = {
  welcome:  $("#screen-welcome"),
  support:  $("#screen-support"),
  level:    $("#screen-level"),
  quiz:     $("#screen-quiz"),
  results:  $("#screen-results"),
};

// ── All frequently-used DOM elements, cached for performance ──
const dom = {
  // Welcome
  nameInput:          $("#input-name"),
  nameError:          $("#name-error"),
  categorySelect:     $("#input-category"),
  accommodationInput: $("#input-accommodation"),
  btnStart:           $("#btn-start"),
  btnHome:            $("#btn-home"),
  journeySteps:       $("#journey-progress"),
  startHint:          $("#start-hint"),
  welcomeForm:        $("#welcome-form"),
  roleScreen:         $("#screen-role"),
  supportOptions:     $("#support-options"),
  supportReadAloud:   $("#support-read-aloud"),
  btnReadAloud:       $("#btn-read-aloud"),
  btnStopReading:     $("#btn-stop-reading"),

  // Education Level
  levelCardsContainer: $("#level-cards"),
  btnBeginQuiz:        $("#btn-begin-quiz"),
  levelHint:           $("#level-hint"),

  // Quiz
  sectionLabel:   $("#quiz-section-label"),
  progressText:   $("#quiz-progress-text"),
  progressBarCont:$("#quiz-progress-bar-container"),
  progressBar:    $("#quiz-progress-bar"),
  questionTitle:  $("#quiz-question"),
  optionsContainer: $("#quiz-options"),
  btnNext:        $("#btn-next"),
  btnSkip:        $("#btn-skip"),
  btnPrevious:    $("#btn-previous"),
  questionNavigator: $("#question-navigator"),
  quizFeedback:   $("#quiz-feedback"),

  // Results
  resultScore:     $("#result-score"),
  resultPercent:   $("#result-percent"),
  resultSections:  $("#result-sections"),
  answerReview:    $("#answer-review"),
  resultRecommend: $("#result-recommendation"),
  resultLevel:     $("#result-level"),
  btnSubmit:       $("#btn-submit"),
  submitStatus:    $("#submit-status"),
  btnRestart:      $("#btn-restart"),
};

/**
 * Switch the visible screen. Uses class toggles so CSS transitions work
 * and screen-reader announcements fire correctly.
 *
 * @param {"role"|"welcome"|"support"|"level"|"quiz"|"results"} name
 */
function showScreen(name) {
  document.getElementById("main-content").classList.toggle("landing-mode", name === "role");
  Object.values(screens).forEach(s => s.classList.remove("active"));
  dom.roleScreen.classList.remove("active");
  dom.roleScreen.hidden = name !== "role";
  dom.journeySteps.hidden = name === "role";
  if (name === "role") {
    dom.roleScreen.classList.add("active");
    dom.btnHome.hidden = true;
    dom.roleScreen.setAttribute("tabindex", "-1");
    dom.roleScreen.focus({ preventScroll: false });
    window.scrollTo({ top: 0, behavior: "smooth" });
    return;
  }
  screens[name].classList.add("active");
  dom.btnHome.hidden = false;

  const screenOrder = ["welcome", "support", "level", "quiz", "results"];
  const currentStep = screenOrder.indexOf(name);
  dom.journeySteps.querySelectorAll("[data-step]").forEach((step, index) => {
    step.classList.toggle("is-complete", index < currentStep);
    step.classList.toggle("is-current", index === currentStep);
    if (index === currentStep) {
      step.setAttribute("aria-current", "step");
    } else {
      step.removeAttribute("aria-current");
    }
  });
  // Move focus to the screen container for screen-reader users
  screens[name].setAttribute("tabindex", "-1");
  screens[name].focus({ preventScroll: false });
  window.scrollTo({ top: 0, behavior: "smooth" });
}
